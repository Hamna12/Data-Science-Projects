
import tkinter
from tkinter import *

root = Tk()

#creating a label widget
myLabel = Label(root, text="Hello World!")

# Showing it onto the screen
myLabel.pack()

root.mainloop()


