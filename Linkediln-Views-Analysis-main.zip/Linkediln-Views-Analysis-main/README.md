# Linkediln-Views-Analysis
LinkedIn doesn't offer content analytics other than for each individual post separately.  What if we want to see performance of our posts (likes, views, comments) over the past month?  I wrote a program in Python that would visualize whether the number of views on my post went up or down over the past days, and here is what I got:
