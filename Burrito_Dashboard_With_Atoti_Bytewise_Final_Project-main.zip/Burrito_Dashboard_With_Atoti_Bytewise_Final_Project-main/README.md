# Burrito_Dashboard_With_Atoti_DS_Project

# What is Burrito?
burrito, canonically pronounced boar-eee-toe, is a Python framework for wrapping and controlling command-line applications. 
This tool allows developers to wrap command-line applications, just as burritos wrap delicious foods. Both hide the potentially unsightly details.

