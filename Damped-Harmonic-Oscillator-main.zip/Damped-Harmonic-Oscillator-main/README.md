# Damped-Harmonic-Oscillator
A complete project contains python code, and complete project report.
